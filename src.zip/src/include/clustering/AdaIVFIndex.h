// adaivf_index.h
#pragma once

#include <vector>
#include <memory>
#include <cstddef>

#include "ClusterManager.h"
#include "VectorRouter.h"
#include "PostingList.h"
#include "UpdateEngine.h"

class AdaIVFIndex {
public:
    AdaIVFIndex(size_t dim, size_t num_clusters, size_t routing_k);
    void Build(const std::vector<std::vector<float>>& base_vectors);
    void Add(const std::vector<float>& vec, size_t vec_id);
    void Remove(size_t vec_id);
    std::vector<size_t> Search(const std::vector<float>& query, size_t topk);

private:
    size_t dim_;
    size_t num_clusters_;
    size_t routing_k_;

    std::unique_ptr<ClusterManager> cluster_manager_;
    std::unique_ptr<VectorRouter> vector_router_;
    std::unique_ptr<PostingList> posting_list_;
    std::unique_ptr<UpdateEngine> update_engine_;
};
